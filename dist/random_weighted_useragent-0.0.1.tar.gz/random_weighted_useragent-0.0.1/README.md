Randomly swaps between useragents with weights for a statistically "normal" distribution.

Usage:
```python
from random_useragent import generate_ua

```
