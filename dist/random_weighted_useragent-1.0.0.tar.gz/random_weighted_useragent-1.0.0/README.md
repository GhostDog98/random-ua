Randomly swaps between useragents with weights for a statistically "normal" distribution.

Usage:
```python
from random_weighted_useragent import *
random_useragent()
```
